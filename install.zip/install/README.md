<div align="center">

# MAA_SnowBreak

基于全新架构的 尘白禁区 小助手。图像技术 + 模拟控制，解放双手！  
由 [MaaFramework](https://github.com/MaaXYZ/MaaFramework) 强力驱动！


</div>

## 主要功能

- 启动/关闭游戏
- 领取邮件
- 商店自动购买芳烃塑料
- 领取体力
- 日常作战和活动作战
- 刷天启碎片
- 领取凭证和任务奖励

## 使用说明

下载地址：<https://github.com/overflow65537/MAA_SnowBreak/releases>
-解压后运行 MaaPiCli.exe 即可
